//Paarth Jamdagneya
#include <iostream>
#include <fstream>
#include <iomanip>
#include "student.h"
#include "bubble.h"
using namespace std;

struct classStats{
  float mean;
  float min;
  float max;
  float median;
  char * name;
};

float max(student *maximumArrr[], int size){
  float maxi = maximumArrr[0]->mean;

  for (int i = 0; i < size; ++i){
    if (maxi < maximumArrr[i]->mean){
      maxi = maximumArrr[i]->mean;
    }
  }

  return maxi;
}

float min(student *miniArrr[], int size){
  float mini = miniArrr[0]->mean;

  for (int i = 0; i < size; ++i){
    if (mini > miniArrr[i]->mean){
      mini = miniArrr[i]->mean;
    }
  }
  
  return mini;
}

float averageMean(student *avgArr[], int size){
  float mean;
  float totalScore = 0.00;
  int number = 0;

  for (int i = 0; i < size; ++i){
    totalScore += avgArr[i]->mean;
    number += 1;
  }

  mean = totalScore/number;
  return mean;
}

float Med(student *medianArr[], int size){
  float median = 0.00;

  if (size%2 == 0){
    median = (medianArr[size/2 - 1]->mean + medianArr[size/2]->mean)/2;
  }
  else {
    median = medianArr[size/2]->mean;
  }

  return median;
}

int main()
{
  ifstream fin;
  string className;
  classStats statistics;
  int size = 19;
  student *studentList[size];


  fin.open("grades");
 
  for (int i = 0; i < size; ++i){
    studentList[i] = (student *)malloc(sizeof(student));
    studentList[i]->first = (char *)malloc(sizeof(char *));
    studentList[i]->last = (char *)malloc(sizeof(char *));
    statistics.name = (char *)malloc(sizeof(char *));
  }

  fin >> statistics.name;


  for (int i = 0; i < size; ++i){
    fin >> studentList[i]->first;
    fin >> studentList[i]->last;
    fin >> studentList[i]->exam1;
    fin >> studentList[i]->exam2;
    fin >> studentList[i]->exam3;
   

    studentList[i]->mean = (studentList[i]->exam1 + studentList[i]->exam2 + studentList[i]->exam3) / 3.00;
  }

  bubble(studentList, size);

  statistics.max = max(studentList,size);
  statistics.min = min(studentList, size);
  statistics.mean = averageMean(studentList, size);
  statistics.median = Med(studentList, size);






  cout << "123456789012345678901234567890123456789012345678901234567890" << endl;
  cout << statistics.name << setw(5) << fixed << " MEAN:  ";
  cout << setw(5) << setprecision (2) << fixed << statistics.mean << " MIN:  " << setw(5) << statistics.min << " MAX:  " << setw(5) << statistics.max << " MEDIAN:  " << setw(5) << statistics.median << endl;
 
 
  for (int i = 0; i < size; ++i){
    cout << setw(12) << setprecision(2) << fixed << studentList[i]->first << setw(12) << studentList[i]->last << " " << setw(3) << studentList[i]->mean << endl;
  }

  for (int i = 0; i < size; ++i){
    free(studentList[i]->first);
    free(studentList[i]->last);
    free(studentList[i]);
  }
  return 0;
}
