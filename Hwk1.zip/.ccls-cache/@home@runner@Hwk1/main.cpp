#include <iostream>
#include "student.h"
using namespace std;

struct classStats {
  float mean;
  float min;
  float max;
  float median;
  char* name;
};

int main() {
  freopen("grades","r",stdin);
  classStats stat;
  student* ptr;
  ptr = (student*)malloc(19*sizeof(student));

  for (int i = 0; i < 19; ++i) {
    scanf("%s", ptr[i].first);
    scanf("%s", ptr[i].last);
    scanf("%d", &ptr[i].exam1);
    scanf("%d", &ptr[i].exam2);
    scanf("%d", &ptr[i].exam3);
  }

  for (int i = 0; i < 19; ++i) {
    cout << ptr[i].first << endl;
  }
}