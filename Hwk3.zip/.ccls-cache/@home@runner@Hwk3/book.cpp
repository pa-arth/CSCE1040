/* 
* CSCE 1040 Homework 3 
* Section: 001
* Name: Paarth Jamdagneya
* UNT Email: paarthjamdagneya@my.unt.edu
* Date submitted: 04/25/2022
*File name: book.cpp
*Description:  In this file it defines each of the functions of the book class which are simply accessor/mutators for each data variable along with a printall.
*/ 
#ifndef book
#define book
#include <iostream>
#include <string>
#include "book.h"
using namespace std;

Book::Book(){
    author = "";
    title = "";
    isbn = 0;
    id = 0;
    cost = 0;
    status = "";
}

string Book::getAuthor(){
    return author;
}

string Book::getTitle(){
    return title;
}

int Book::getISBN(){
    return isbn;
}

int Book::getID(){
    return id;
}

float Book::getCost(){
    return cost;
}

string Book::getStatus(){
    return status;
}

void Book::setAuthor(string author){
  this->author = author;
}

void Book::setTitle(string title){
  this->title = title;
}

void Book::setISBN(int isbn){
  this->isbn = isbn;
}

void Book::setID(int id){
  this->id = id;
}

void Book::setCost(float cost){
  this->cost = cost;
}

void Book::setStatus(string status){
  this->status = status;
}

Book::Book(string author, string title, int isbn, int id, float cost, string status) {
    this->author = author;
    this->title = title;
    this->isbn = isbn;
    this->id = id;
    this->cost = cost;
    this->status = status;
}

void Book::print(){
    cout << "Author: " << author << endl;
    cout << "Title: " << title << endl;
    cout << "ISBN Number: " << isbn << endl;
    cout << "ID Number: " << id << endl;
    cout << "Cost: " << cost << endl;
    cout << "Status: " << status << endl;
}
#endif