/* 
* CSCE 1040 Homework 3 
* Section: 001
* Name: Paarth Jamdagneya
* UNT Email: paarthjamdagneya@my.unt.edu
* Date submitted: 04/25/2022
*File name: book.h
*Description:  In this file it declares the book class and just sets out the specific functions and variables used in the program.
*/ 
#ifndef HI
#define HI
#include <iostream>
#include <string>
using namespace std;

class Book {
  public:
  Book();
  Book(string author, string title, int isbn, int id, float cost, string status);
  string getAuthor();
  string getTitle();
  int getISBN();
  int getID();
  float getCost();
  string getStatus();
  void setAuthor(string author);
  void setTitle(string title);
  void setISBN(int isbn);
  void setID(int id);
  void setCost(float cost);
  void setStatus(string status);
  void add(string author, string title, int isbn, int id, float cost, string status);
  void print();
  private:
  string author;
  string title;
  int isbn;
  int id;
  float cost;
  string status;
};
#endif