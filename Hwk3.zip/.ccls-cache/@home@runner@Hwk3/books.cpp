/* CSCE 1040 Homework 3 
* Section: 001
* Name: Paarth Jamdagneya
* UNT Email: paarthjamdagneya@my.unt.edu
* Date submitted: 04/25/2022
*File name: books.cpp
*Description:  In this file it defines each of the functions of the books class which are adding, deleting, searching, and printing specific books.
*/ 
#include <iostream>
#include "books.h"
#include "book.h"
#include <fstream>
#include <vector>
using namespace std;

Books::Books(){
  vector<Book> books;
  vector<Book> bookSearch;
}

void Books::add(Book book){
  books.push_back(book);
}

void Books::edit(Book book){
  bool check = false;
  for (int i = 0; i < books.size(); i ++){
    if (book.getID() == books[i].getID()){
      books[i] = book;
      check = true;
    }
  }
  if (check == false){
    cout << "No book found." << endl;
    exit(0);
  }
}

void Books::remove(int id){
  bool check = false;
  for (int i = 0; i < books.size(); i ++){
    if (id == books[i].getID()){
      books.erase(books.begin() + i);
      check = true;
    }
  }
  if (check == false){
    cout << "No book found." << endl;
    exit(0);
  }
}

void Books::search() {
  int id;
  bool found = false;
  cout << "Please enter the book's library ID: " << endl;
    cin >> id;
    for (int i = 0; i < books.size(); i ++){
        if (id == books[i].getID()){
          found = true;
          bookSearch.push_back(books[i]);
          cout << "Book has been added to book search list." << endl;
        }
      }
    if (found == false){
      cout << "No book found number." << endl;
      exit(0);
      }
}

void Books::print(){
    search();
    cout << "Author: " << books[books.size()-1].getAuthor() << endl;
    cout << "Title: " << books[books.size()-1].getTitle() << endl;
    cout << "ISBN number: " << books[books.size()-1].getISBN() << endl;
    cout << "ID Number: " << books[books.size()-1].getID() << endl;
    cout << "Cost: " << books[books.size()-1].getCost() << endl;
    cout << "Status: " << books[books.size()-1].getStatus() << endl;
}

void Books::printAll(){
  if (books.size() == 0){
    cout << "No books are currently checked out." << endl;
  }
  for (int i = 0; i < books.size(); i ++){
    cout << "Book " << i + 1 << ": " << endl;
    cout << "Author: " << books[i].getAuthor() << endl;
    cout << "Title: " << books[i].getTitle() << endl;
    cout << "ISBN number: " << books[i].getISBN() << endl;
    cout << "ID Number: " << books[i].getID() << endl;
    cout << "Cost: " << books[i].getCost() << endl;
    cout << "Status: " << books[i].getStatus() << endl << endl;
  }
}

Book Books::getLast() {
  Book book;
  if (bookSearch.size()!= 0)
  return bookSearch[bookSearch.size()-1];
  else {
    return book;
    }
}