/* 
* CSCE 1040 Homework 3 
* Section: 001
* Name: Paarth Jamdagneya
* UNT Email: paarthjamdagneya@my.unt.edu
* Date submitted: 04/25/2022
*File name: books.h
*Description:  In this file it declares the books class and just sets out the specific functions and variables used in the program.
*/ 
#ifndef Bye
#define Bye
#include <iostream>
#include <string>
#include <vector>
#include "book.h"
using namespace std;

class Books {
  public:
    Books();
    void add(Book book);
    void edit(Book book);
    void remove(int id);
    void search();
    void printAll();
    void print();
    void test(ifstream& fin);
    Book getLast();

  private:
    vector<Book> books;
    vector<Book> bookSearch;
};
#endif