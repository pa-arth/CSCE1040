/* 
* CSCE 1040 Homework 3 
* Section: 001
* Name: Paarth Jamdagneya
* UNT Email: paarthjamdagneya@my.unt.edu
* Date submitted: 04/25/2022
*File name: loan.cpp
*Description:  In this file it defines each of the functions of the loan class which are simply accessor/mutators for each data variable.
*/ 
#include <iostream>
#include <string>
#include "loan.h"
#include "book.h"
#include "patron.h"
#include "patrons.h"
#include "books.h"
#include <algorithm>
using namespace std;

Loan::Loan(){
  id = 0;
  patronID = 0;
  bookID = 0;
  dueDate = time(0) + 864000;
  status = "";
}

Loan::Loan(int id, Patron patron, Book book, time_t dueDate, string status){
  this->id = id;
  this->patron = patron;
  this->book = book;
  this->dueDate = dueDate;
  this->status = status;
}

int Loan::getID(){
  return id;
}

Patron Loan::getPatron(){
  return patron;
}

Book Loan::getBook(){
  return book;
}

time_t Loan::getDueDate(){
  return dueDate;
}

string Loan::getStatus(){
  return status;
}

void Loan::setID(int id){
  this->id = id;
}

void Loan::setPatron(Patron patron){
  this->patron = patron;
}

void Loan::setBook(Book book){
  this->book = book;
}

void Loan::setDueDate(time_t time) {
  dueDate = time;
}

void Loan::setStatus(string status){
  this->status = status;
}

