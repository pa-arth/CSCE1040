/*
* CSCE 1040 Homework 3 
* Section: 001
* Name: Paarth Jamdagneya
* UNT Email: paarthjamdagneya@my.unt.edu
* Date submitted: 04/25/2022
*File name: loan.h
*Description:  In this file it declares the loan class and just sets out the specific functions and variables used in the program.
*/

#ifndef RAND
#define RAND
#include <iostream>
#include <string>
#include "patron.h"
#include "book.h"
#include "books.h"
#include "patrons.h"
using namespace std;

class Loan {
  public:
    Loan();
    Loan (int id, Patron patron, Book book, time_t dueDate, string status);
    int getID();
    int getBookID();
    int getPatronID();
    Patron getPatron();
    Book getBook();
    time_t getDueDate();
    string getStatus();
    void setID(int id);
    void setPatron(Patron patron);
    void setBook (Book book);
    void setDueDate(time_t time);
    void setStatus(string status);
  

  private:
    int id;
    int bookID;
    int patronID;
    Patron patron;
    Book book;
    time_t dueDate;
    string status;

};
#endif