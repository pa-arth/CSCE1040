/* 
* CSCE 1040 Homework 3 
* Section: 001
* Name: Paarth Jamdagneya
* UNT Email: paarthjamdagneya@my.unt.edu
* Date submitted: 04/25/2022
*File name: loan.cpp
*Description:  In this file it defines each of the functions of the loans class which are checking out a book, checking in a book, listing the overdue books, listing all the books out for a particular patron, updating loan status, rechecking out a book, editing a loan, and reporting a book as lost.
*/ 
#include "loans.h"
#include "patrons.h"
#include "books.h"
#include "book.h"
#include "patron.h"
#include "loan.h"
#include <fstream>
#include <iostream>

using namespace std;
 Loans::Loans(){
   vector<Loan> loanList;
 }

void Loans::edit(Loan loan){
  bool check = false;
  for (int i = 0; i < loanList.size(); i ++){
    if (loan.getID() == loanList[i].getID()){
      loanList[i].setID(loan.getID());
      loanList[i].setPatron(loan.getPatron());
      loanList[i].setBook(loan.getBook());
      loanList[i].setStatus(loan.getStatus());
      check = true;
    }
  }
  if (check == false){
    cout << "No Loan Found." << endl;
    
  }
}
void Loans::checkOut(Book book, Patron patron) {
  Loan loan (rand()%1000, patron, book, time(0) + 864000, "normal");
  loanList.push_back(loan);
}

void Loans::checkIn() {
  int loanID;
  cout << "Please enter the loan ID: ";
  cin >> loanID;
  for (int i = 0; i < loanList.size();++i) {
    if (loanList[i].getID() == loanID) {
      if (loanList[i].getPatron().getFine() == 0)
      loanList.erase(loanList.begin()+i);
      else {
        cout << "Please pay the required fines: $" << loanList[i].getPatron().getFine() << endl;
        loanList.erase(loanList.begin()+i);
        }
    }
  }
}

void Loans::updateStatus(int bookID){
  bool check = false;
  for (int i = 0; i < loanList.size(); i ++){
    if (bookID == loanList[i].getBook().getID()){
      if (loanList[i].getStatus() == "Overdue"){
        check = true;
      }
      loanList.erase(loanList.begin() + i);
    }
  }
}

void Loans::allOverdue(){
  for (int i = 0; i < loanList.size(); i ++){
    if (loanList[i].getStatus() == "Overdue"){
      cout << "Loan ID: " << loanList[i].getID() << endl;
      cout << "Book ID: " << loanList[i].getBook().getID() << endl;
      cout << "Patron ID: " << loanList[i].getPatron().getID() << endl << endl;
    }
  }
}

void Loans::listPatron(int id){
  for (int i = 0; i < loanList.size(); i ++){
    if (id == loanList[i].getPatron().getID()){
      cout << "Loan ID: " << loanList[i].getID() << endl;
      cout << "Book ID: " << loanList[i].getBook().getID() << endl;
      cout << "Patron ID: " << loanList[i].getPatron().getID() << endl;
      cout << "Due date: " << loanList[i].getDueDate() << endl << endl;
    }
  }
}

void Loans::reCheck(int bookID){
  for (int i = 0; i < loanList.size(); i ++){
    if (loanList[i].getBook().getID() == bookID){
      time_t now = time(0);
      loanList[i].setDueDate(now+864000);
    }
  }
}

  void Loans::reportLost(int bookID){
  for (int i = 0; i < loanList.size(); i ++){
    if (bookID == loanList.at(i).getBook().getID()){
      loanList.at(i).getPatron().setFine(loanList.at(i).getBook().getCost());
      loanList.at(i).getBook().setStatus("Lost");
      
    }
  }
}

void Loans::checkOverdue(){
  time_t now = time(0);
  for (int i = 0; i < loanList.size(); i ++){
    if (now > loanList[i].getDueDate()){
      loanList[i].setStatus("Overdue");
    }
  }  
} 