/* 
* CSCE 1040 Homework 3 
* Section: 001
* Name: Paarth Jamdagneya
* UNT Email: paarthjamdagneya@my.unt.edu
* Date submitted: 04/25/2022
*File name: loans.h
*Description:  In this file it declares the loans class and just sets out the specific functions and variables used in the program.
*/ 
#ifndef BLUE
#define BLUE
#include <iostream>
#include <vector>
#include "loan.h"
#include "patrons.h"
#include "books.h"
#include "book.h"
#include "patron.h"

class Loans{
  public:
  Loans();
  void edit(Loan loan);
  void checkOut(Book book, Patron patron);
  void checkIn ();
  void updateStatus(int bookID);
  void allOverdue();
  void listPatron(int id);
  void reCheck(int bookID);
  void reportLost(int bookID);
  void test(ifstream& fin);
  void checkOverdue();

  private:
    vector<Loan> loanList;
};
#endif