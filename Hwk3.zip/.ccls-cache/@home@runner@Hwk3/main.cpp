/* 
 * CSCE 1040 Homework 3 
 * Section: 001
 * Name: Paarth Jamdagneya
 * UNT Email: paarthjamdagneya@my.unt.edu
 * Date submitted: 04/25/2022
 *File name: main.cpp
 *Description:  In this file we are giving the user their various options and calling the necessary functions in order to execute their inputs. 
 */
#include <iostream>

#include "loan.h"

#include "patron.h"

#include "book.h"

#include "loans.h"

#include "patrons.h"

#include "books.h"

#include <vector>

#include <ctime>

#include <fstream>

using namespace std;

int main() {
    bool loop = true;
    char option;
    Books books;
    Patrons patrons;
    Loans loans;
    string title;
    string author;
    int isbn;
    int bookID;
    int cost;
    string status;
    string patronName;
    int patronID;
    float fine;
    int booksOut;
    int loanID;
    string dueDate;

    do {
      cout << "Which option would you like to select? Books(click b), Patrons(click p), Loans(click l), or Quit (click q): ";
      cin >> option;
      switch (option) {
      case 'b': {
        cout << "Do you want to add(click a), edit(click e), delete(click d), search(click s), print a singlular book (click f), or print all the books (click p)?" << endl;
        cin >> option;
        switch (option) {
        case 'a': {
          cout << "Please enter the author: ";
          cin.ignore();
          getline(cin, author);
          cout << "Please enter the title: ";
          getline(cin, title);
          cout << "Please enter the ISBN number: ";
          cin >> isbn;
          cout << "Please enter the book ID: ";
          cin >> bookID;
          cout << "Please enter the cost: ";
          cin >> cost;
          status = "Normal";
          Book tempBook (author, title, isbn, bookID, cost, status);
          books.add(tempBook);
          break;
          }

        case 'e': {
          cout << "Please enter the ID number of the book you would like to edit: ";
          cin >> bookID;
          cout << "Please enter the author: ";
          cin.ignore();
          getline(cin, author);
          cout << "Please enter the title: ";
          getline(cin, title);
          cout << "Please enter the ISBN number: ";
          cin >> isbn;
          cout << "Please enter the cost: ";
          cin >> cost;
          cout << "Please enter the status of the book: ";
          cin >> status;
          Book tempBook(author, title, isbn, bookID, cost, status);
          books.edit(tempBook);
          break;
          }
        case 'd': {
          cout << "Please enter the book ID of the book you wish to delete: ";
          cin >> bookID;
          books.remove(bookID);
          break;
          }
        case 's': {
          books.search();
          break;
          }
        case 'f': {
          books.print();
          break;
          }
        case 'p': {
          books.printAll();
          break;
          }
        }
        break;
      }
      case 'p': {
        cout << "Do you want to add(click a), edit(click e), delete(click d), search(click s), pay fines (g), print a singlular patron (click f), or print all the patrons (click p)?" << endl;
        cin >> option;
        switch (option) {
        case 'a': {
          cout << "Please enter the name of the patron: ";
          cin.ignore();
          getline(cin, patronName);
          cout << "Please enter the patron's ID number: ";
          cin >> patronID;
          fine = 0;
          booksOut = 0;
          Patron tempPatron(patronName, patronID, fine, booksOut);
          patrons.add(tempPatron);
          break;
        }

        case 'e': {
          cout << "Please enter the ID of the patron you wish to edit: ";
          cin >> patronID;
          cout << "Please enter the name of the patron: ";
          cin.ignore();
          getline(cin, patronName);
          cout << "Please enter the fine amount of the patron: ";
          cin >> fine;
          cout << "Please enter the patron's number of books out: ";
          cin >> booksOut;
          Patron newPatron(patronName, patronID, fine, booksOut);
          patrons.edit(newPatron);
          break;
        }

        case 'd': {
          cout << "Please enter the ID of the patron you wish to delete: ";
          cin >> patronID;
          patrons.remove(patronID);
          break;
        }

        case 's': {
          patrons.search();
          cout << "The patron has been added to the search list.";
          break;
        }
          case 'g': {
            cout << "Please enter the patron ID for which you wish to pay the fines: ";
            cin >> patronID;
            patrons.payFines(patronID);
          } 
        case 'f': {
          patrons.print();
          cout << endl;
          break;
        }
        case 'p': {
          patrons.printAll();
          break;

        }
        break;
    }
        break;
        }
      case 'l': {
          cout << "Do you want to check out a book(enter c), check in a book(enter i), list all overdue books(enter o), list all loans for a patron (enter p), recheck a book (enter r), edit a loan(enter e), or report a book as lost (enter b)?" << endl;
          cin >> option;
          switch (option) {
          case 'c': {
            books.search();
            patrons.search();
            loans.checkOut(books.getLast(),               patrons.getLast());

            break;
            }
          case 'i': {
            loans.checkIn();
            break;
          }

          case 'o': {
            loans.allOverdue();
            break;
          }

          case 'p': {
            cout << "Please enter the patron ID: ";
            cin >> patronID;
            loans.listPatron(patronID);
            break;
          }

          case 'r': {
            cout << "Please enter the book ID: ";
            cin >> bookID;
            loans.reCheck(bookID);
            cout << "Your due date is now " << time(0) + 864000 << "." << endl;
            break;
          }

          case 'e': {
            cout << "Please enter the ID of the loan you wish to edit: ";
            cin >> loanID;
            books.search();
            patrons.search();
            cout << "Please enter the status: ";
            cin >> status;
            Loan tempLoan(loanID, patrons.getLast(), books.getLast(), time(0), status);
            loans.edit(tempLoan);
            break;
          }

          case 'b': {
            cout << "What is the book ID of the lost book?" << endl;
            cin >> bookID;
            loans.reportLost(bookID);

            cout << "We have fined the account holding the book for the cost of the book." << endl;
          }
          break;
          }
        break;
        }
      case 'q': {
            loop = false;
            break;
            }
      default: {
            cout << "Please enter a menu option." << endl;
            break;
        
      }
      }
  } while (loop == true);

      return 0;
    }