/* 
* CSCE 1040 Homework 3 
* Section: 001
* Name: Paarth Jamdagneya
* UNT Email: paarthjamdagneya@my.unt.edu
* Date submitted: 04/25/2022
*File name: loan.cpp
*Description:  In this file it defines each of the functions of the patron class which are simply accessor/mutators for each data variable.
*/ 
#include <iostream>
#include <string>
#include "patron.h"
#include "book.h"
#include "books.h"
using namespace std;

Patron::Patron(){
    name = "";
    id = 0;
    fine = 0;
    booksOut = 0;
}

Patron::Patron(string name, int id, float fine, int booksOut){
    this->name = name;
    this->id = id;
    this->fine = fine;
    this->booksOut = booksOut;
}

string Patron::getName(){
    return name;
}

int Patron::getID(){
    return id;
}

float Patron::getFine(){
    return fine;
}

int Patron::getBooksOut(){
    return booksOut;
}

void Patron::setName(string name){
  this->name = name;
}

void Patron::setID(int id){
  this->id = id;
}

void Patron::setFine(float fine){
  this->fine = fine;
}

void Patron::setBooksOut(int booksOut){
  this->booksOut = booksOut;
}