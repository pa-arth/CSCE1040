/* 
* CSCE 1040 Homework 3 
* Section: 001
* Name: Paarth Jamdagneya
* UNT Email: paarthjamdagneya@my.unt.edu
* Date submitted: 04/25/2022
*File name: patron.h
*Description:  In this file it declares the patron class and just sets out the specific functions and variables used in the program.
*/ 
#ifndef DOES
#define DOES
#include <iostream>
#include <string>
#include "book.h"
#include "books.h"
using namespace std;

class Patron {
  public:
    Patron();
    Patron(string name, int id, float fine, int booksOut);
    string getName();
    int getID();
    float getFine();
    int getBooksOut();
    void setName(string name);
    void setID(int id);
    void setFine(float fine);
    void setBooksOut(int booksOut);

  private:
    string name;
    int id;
    float fine;
    int booksOut;
};
#endif