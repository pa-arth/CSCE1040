/* 
* CSCE 1040 Homework 3 
* Section: 001
* Name: Paarth Jamdagneya
* UNT Email: paarthjamdagneya@my.unt.edu
* Date submitted: 04/25/2022
*File name: loan.cpp
*Description:  In this file it defines each of the functions of the loans class which are adding a patron, editing a patron, deleting a patron, searching for a patron, print a list of entries of the patron, printing the details for a single patron, and finally paying the fines on the account.
*/ 
#include <iostream>
#include <vector>
#include "patrons.h"
#include "patron.h"
#include "books.h"
#include "book.h"
#include <fstream>
using namespace std;

Patrons::Patrons () {
vector <Patron> patrons;
vector <Patron> patronSearch;
  }
void Patrons::add(Patron patron){
  patrons.push_back(patron);
}

void Patrons::edit(Patron patron){
  bool check = false;
  for (int i = 0; i < patrons.size(); i ++){
    if (patron.getID() == patrons[i].getID()){
      patrons[i] = patron;
      check = true;
    }
  }
  if (check == false){
    cout << "No patron found." << endl;
  }
}

void Patrons::remove(int id){
  bool check = false;
  for (int i = 0; i < patrons.size(); i ++){
    if (id == patrons[i].getID()){
      patrons.erase(patrons.begin() + i);
      check = true;
    }
  }
  if (check == false){
    cout << "No patron found." << endl;
  }
}

void Patrons::search(){
  bool found = false;
  int patronID;
    cout << "Enter the patron's ID number: ";
    cin >> patronID;
    found = false;
    for (int i = 0; i < patrons.size(); i ++){
      if (patronID == patrons[i].getID()){
        found = true;
        patronSearch.push_back(patrons[i]);
      }
    }
    if (found == false){
      cout << "No patron found." << endl;
      } 
}

void Patrons::print() {
    search();
    cout << "Patron name: " << patrons[patrons.size()-1].getName() << endl;
    cout << "Patron ID number: " << patrons[patrons.size()-1].getID() << endl;
    cout << "Patron's fine amount: " << patrons[patrons.size()-1].getFine() << endl;
    cout << "Patron's number of books out: " << patrons[patrons.size()-1].getBooksOut() << endl;
  }

void Patrons::printAll(){
  if (patrons.size() == 0){
    cout << "No patrons in the system." << endl;
  }
  for (int i = 0; i < patrons.size(); i ++){
    cout << "Patron name: " << patrons[i].getName() << endl;
    cout << "Patron ID number: " << patrons[i].getID() << endl;
    cout << "Patron's fine amount: " << patrons[i].getFine() << endl;
    cout << "Patron's number of books out: " << patrons[i].getBooksOut() << endl << endl;
  }
}

void Patrons::payFines(int id){
  for (int i = 0; i < patrons.size(); i ++){
    if (id == patrons[i].getID()){
      if (patrons[i].getFine() > 0){
        cout << "You owe $" << patrons[i].getFine() << endl;
        patrons[i].setFine(0);
      }
    }
  }
}

Patron Patrons::getLast() {
  if (patronSearch.size()!= 0)
  return patronSearch[patronSearch.size()-1];
}
