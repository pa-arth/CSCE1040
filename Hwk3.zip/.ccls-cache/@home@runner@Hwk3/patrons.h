/* 
* CSCE 1040 Homework 3 
* Section: 001
* Name: Paarth Jamdagneya
* UNT Email: paarthjamdagneya@my.unt.edu
* Date submitted: 04/25/2022
*File name: patrons.h
*Description:  In this file it declares the patrons class and just sets out the specific functions and variables used in the program.
*/ 
#ifndef CUZ
#define CUZ
#include <iostream>
#include <vector>
#include "patron.h"
#include "books.h"
#include "book.h"
using namespace std;

class Patrons {
  public:
  Patrons();
  void add(Patron patron);
  void edit(Patron patron);
  void remove(int id);
  void search();
  void printAll();
  void print();
  void payFines(int id);
  Patron getLast();
  void test(ifstream& fin);
  

  private:
  vector <Patron> patrons;
  vector <Patron> patronSearch;
  
};
#endif